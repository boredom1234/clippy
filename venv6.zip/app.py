from flask import Flask,render_template,request,redirect,url_for,flash,session
import sqlite3 as sql
app=Flask(__name__)

# IS_ADMIN
def is_admin():
    return session.get('is_admin')

# HOME
@app.route("/")
@app.route("/home")
def home():
    return render_template("home.html")

# ADMIN_VIEW
@app.route("/index")
def index():
    if not is_admin():
        return "Admin access only"
    else:
        con = sql.connect("db_web.db")
        con.row_factory = sql.Row
        cur = con.cursor()
        cur.execute("select * from users")
        data = cur.fetchall()
        return render_template("index.html", datas=data)

# REGISTER
@app.route("/register",methods=['POST','GET'])
def register():
    if request.method=='POST':
        uname=request.form['uname']
        contact=request.form['contact']
        con=sql.connect("db_web.db")
        cur=con.cursor()
        
        # Check if username already exists
        cur.execute("SELECT * FROM users WHERE UNAME=?", (uname,))
        existing_user = cur.fetchone()
        if existing_user:
            flash('Username already exists', 'warning')
            return redirect(url_for("register"))  # Redirect back to registration page
        
        # If username doesn't exist, insert the new user
        cur.execute("INSERT INTO users(UNAME,CONTACT) VALUES (?,?)", (uname, contact))
        con.commit()
        flash('User Added', 'success')
        return redirect(url_for("login"))
    return render_template("register.html")

# LOGIN
@app.route("/login",methods=['POST','GET'])
def login():
    if request.method=='POST':
        uname=request.form['uname']
        contact=request.form['contact']
        
        # Check if username and contact are admin
        if uname == 'admin' and contact == 'admin':
            flash('Login Success','success')
            session['is_admin'] = True
            return redirect(url_for("index"))
        
        # If not admin, proceed with regular login check
        con=sql.connect("db_web.db")
        cur=con.cursor()
        cur.execute("select * from users where UNAME=? and CONTACT=?",(uname,contact))
        data=cur.fetchone()
        if data:
            flash('Login Success','success')
            return redirect(url_for("welcome", username=uname))
        else:
            flash('Login Failed','danger')
            return redirect(url_for("login"))
    return render_template("login.html")


# WELCOME
@app.route('/welcome/<username>')
def welcome(username):
    return render_template('welcome_user.html', username=username)

# ADD_USER
@app.route("/add_user",methods=['POST','GET'])
def add_user():
    if request.method=='POST':
        uname=request.form['uname']
        contact=request.form['contact']
        con=sql.connect("db_web.db")
        cur=con.cursor()
        cur.execute("insert into users(UNAME,CONTACT) values (?,?)",(uname,contact))
        con.commit()
        flash('User Added','success')
        return redirect(url_for("index"))
    return render_template("add_user.html")

# EDIT_USER
@app.route("/edit_user/<string:uid>",methods=['POST','GET'])
def edit_user(uid):
    if request.method=='POST':
        uname=request.form['uname']
        contact=request.form['contact']
        con=sql.connect("db_web.db")
        cur=con.cursor()
        cur.execute("update users set UNAME=?,CONTACT=? where UID=?",(uname,contact,uid))
        con.commit()
        flash('User Updated','success')
        return redirect(url_for("index"))
    con=sql.connect("db_web.db")
    con.row_factory=sql.Row
    cur=con.cursor()
    cur.execute("select * from users where UID=?",(uid,))
    data=cur.fetchone()
    return render_template("edit_user.html",datas=data)
    
# DELETE_USER
@app.route("/delete_user/<string:uid>",methods=['GET'])
def delete_user(uid):
    con=sql.connect("db_web.db")
    cur=con.cursor()
    cur.execute("delete from users where UID=?",(uid,))
    con.commit()
    flash('User Deleted','warning')
    return redirect(url_for("index"))

# LOGOUT
@app.route('/logout')
def logout():
    session.pop('is_admin', False)
    return redirect(url_for('login'))
    
if __name__=='__main__':
    app.secret_key='HECKER'
    app.run(debug=True)