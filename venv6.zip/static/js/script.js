document
  .getElementById("registerForm")
  .addEventListener("submit", function (event) {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    var usernamePattern = /^[a-zA-Z]+$/;
    var passwordPattern =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

    var usernameValid = usernamePattern.test(username);
    var passwordValid = passwordPattern.test(password);

    if (!usernameValid) {
      event.preventDefault();
      document.getElementById("usernameError").textContent =
        "Username must contain only characters.";
    } else {
      document.getElementById("usernameError").textContent = "";
    }

    if (!passwordValid) {
      event.preventDefault();
      document.getElementById("passwordError").textContent =
        "Password must contain at least one uppercase letter, one lowercase letter, one special character, one number, and be at least 8 characters long.";
    } else {
      document.getElementById("passwordError").textContent = "";
    }
  });
